Thank you for purchasing Engage: Publish available 
from engagesoftware.com.

For installation instructions and requirements please 
be sure to check out our Engage: Publish Wiki which can be found at 
http://www.engagesoftware.com/Modules/EngagePublish/PublishWiki/tabid/66/Default.aspx

If you purchased the module from engagesoftware.com your 
user account is already setup with the proper permissions for 
1-year of free upgrades. If you purchased the module from 
another source (such as Snowcovered or the DNN Marketplace) 
you will need to provide a copy of your receipt via email 
to dotnetnuke@engagesoftware.net, along with your account 
username for engagesoftware.com.

If you have support questions we offer free support via the 
Forums at engagesoftware.com which can be found at 
http://www.engagesoftware.com/Support/Forums/tabid/57/forumid/2/scope/threads/Default.aspx

We also offer paid support services for all our modules, 
and DotNetNuke in general via http://www.engagesoftware.com/Default.aspx?tabid=59

Thanks again for purchasing Engage: Publish, we hope it proves 
to be as useful for you as it is for us!

Chris Hammond
Lead Developer - Engage: Publish 
DotNetNuke Core Team Member
engagesoftware.com